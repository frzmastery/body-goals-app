export type Gender = "male" | "female";

export type ActivityLevel =
  | "sedentary"
  | "light"
  | "moderate"
  | "active"
  | "very_active";

export type GoalType = "cut" | "maintain" | "bulk";

export interface Profile {
  name: string;
  gender: Gender;
  age: number;
  heightCm: number;
  startWeightKg: number;
  targetWeightKg: number;
  activityLevel: ActivityLevel;
  goalType: GoalType;
  weeklyRateKg: number; // laju perubahan berat per minggu (kg), positif utk bulk, negatif utk cut
  proteinPerKg: number; // gram protein per kg berat badan
  fatPercent: number; // persentase kalori dari lemak
  onboarded: boolean;
}

export interface WeightLog {
  id: string;
  date: string; // yyyy-mm-dd
  weightKg: number;
  note?: string;
}

export type MealType = "sarapan" | "makan_siang" | "makan_malam" | "camilan";

export interface MealEntry {
  id: string;
  date: string;
  mealType: MealType;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  qty: number; // pengali porsi
}

export type ActivityType = "lari" | "jalan_kaki" | "kekuatan" | "lainnya";

export interface ActivityEntry {
  id: string;
  date: string;
  type: ActivityType;
  label: string;
  durationMin: number;
  distanceKm?: number;
  caloriesBurned: number;
}

export interface FoodDbItem {
  id: string;
  name: string;
  unit: string; // e.g. "100 g", "1 porsi", "1 gelas"
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface AppData {
  profile: Profile;
  weightLogs: WeightLog[];
  meals: MealEntry[];
  activities: ActivityEntry[];
  customFoods: FoodDbItem[];
}

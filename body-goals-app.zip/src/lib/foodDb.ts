import { FoodDbItem } from "./types";

// Basis data makanan lokal ringkas (per porsi umum). Nilai gizi perkiraan.
export const FOOD_DB: FoodDbItem[] = [
  { id: "nasi_putih", name: "Nasi putih", unit: "1 centong (100 g)", calories: 175, protein: 3.3, carbs: 38.9, fat: 0.3 },
  { id: "nasi_merah", name: "Nasi merah", unit: "1 centong (100 g)", calories: 165, protein: 3.5, carbs: 34, fat: 1.1 },
  { id: "ayam_goreng", name: "Ayam goreng", unit: "1 potong (100 g)", calories: 260, protein: 24, carbs: 6, fat: 16 },
  { id: "ayam_bakar", name: "Ayam bakar", unit: "1 potong (100 g)", calories: 200, protein: 27, carbs: 2, fat: 9 },
  { id: "telur_ceplok", name: "Telur ceplok", unit: "1 butir", calories: 95, protein: 6.3, carbs: 0.6, fat: 7.3 },
  { id: "telur_rebus", name: "Telur rebus", unit: "1 butir", calories: 78, protein: 6.3, carbs: 0.6, fat: 5.3 },
  { id: "tempe_goreng", name: "Tempe goreng", unit: "2 potong (50 g)", calories: 118, protein: 9, carbs: 7, fat: 7 },
  { id: "tahu_goreng", name: "Tahu goreng", unit: "2 potong (50 g)", calories: 77, protein: 5, carbs: 3, fat: 5 },
  { id: "sayur_bening", name: "Sayur bening bayam", unit: "1 mangkuk", calories: 60, protein: 3, carbs: 8, fat: 1.5 },
  { id: "sate_ayam", name: "Sate ayam (bumbu kacang)", unit: "10 tusuk", calories: 320, protein: 28, carbs: 12, fat: 18 },
  { id: "rendang", name: "Rendang daging", unit: "1 potong (100 g)", calories: 290, protein: 20, carbs: 6, fat: 21 },
  { id: "gado_gado", name: "Gado-gado", unit: "1 porsi", calories: 380, protein: 14, carbs: 40, fat: 18 },
  { id: "soto_ayam", name: "Soto ayam", unit: "1 mangkuk", calories: 250, protein: 18, carbs: 20, fat: 10 },
  { id: "bakso", name: "Bakso sapi", unit: "1 mangkuk (10 butir)", calories: 320, protein: 20, carbs: 30, fat: 12 },
  { id: "mie_goreng", name: "Mie goreng", unit: "1 porsi", calories: 450, protein: 12, carbs: 60, fat: 18 },
  { id: "nasi_goreng", name: "Nasi goreng", unit: "1 porsi", calories: 500, protein: 12, carbs: 65, fat: 20 },
  { id: "pecel_lele", name: "Pecel lele + sambal", unit: "1 porsi", calories: 420, protein: 22, carbs: 35, fat: 22 },
  { id: "gorengan", name: "Gorengan (bakwan/risol)", unit: "1 buah", calories: 110, protein: 2, carbs: 12, fat: 6 },
  { id: "buah_pisang", name: "Pisang", unit: "1 buah sedang", calories: 105, protein: 1.3, carbs: 27, fat: 0.4 },
  { id: "buah_apel", name: "Apel", unit: "1 buah sedang", calories: 95, protein: 0.5, carbs: 25, fat: 0.3 },
  { id: "susu_uht", name: "Susu UHT full cream", unit: "1 gelas (250 ml)", calories: 150, protein: 8, carbs: 12, fat: 8 },
  { id: "kopi_susu", name: "Kopi susu gula aren", unit: "1 gelas (250 ml)", calories: 180, protein: 3, carbs: 28, fat: 6 },
  { id: "roti_tawar", name: "Roti tawar", unit: "2 lembar", calories: 160, protein: 5, carbs: 30, fat: 2 },
  { id: "oatmeal", name: "Oatmeal polos", unit: "1 mangkuk (250 ml)", calories: 150, protein: 5, carbs: 27, fat: 3 },
  { id: "dada_ayam_panggang", name: "Dada ayam panggang tanpa kulit", unit: "100 g", calories: 165, protein: 31, carbs: 0, fat: 3.6 },
  { id: "ikan_bakar", name: "Ikan bakar", unit: "1 ekor sedang (150 g)", calories: 220, protein: 30, carbs: 0, fat: 10 },
  { id: "keripik", name: "Keripik kentang/singkong", unit: "1 bungkus kecil (50 g)", calories: 260, protein: 3, carbs: 28, fat: 16 },
];

export function searchFoodDb(query: string): FoodDbItem[] {
  const q = query.trim().toLowerCase();
  if (!q) return FOOD_DB.slice(0, 8);
  return FOOD_DB.filter((f) => f.name.toLowerCase().includes(q)).slice(0, 12);
}

import { ActivityLevel, Gender, Profile } from "./types";

export const ACTIVITY_FACTORS: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  very_active: 1.9,
};

export const ACTIVITY_LABELS: Record<ActivityLevel, string> = {
  sedentary: "Jarang bergerak (kerja duduk, minim olahraga)",
  light: "Ringan (olahraga 1-3x/minggu)",
  moderate: "Sedang (olahraga 3-5x/minggu)",
  active: "Aktif (olahraga 6-7x/minggu)",
  very_active: "Sangat aktif (fisik berat / atlet)",
};

export const GOAL_LABELS: Record<Profile["goalType"], string> = {
  cut: "Menurunkan berat badan (defisit kalori)",
  maintain: "Menjaga berat badan",
  bulk: "Menambah berat badan (surplus kalori)",
};

/** Mifflin-St Jeor */
export function calcBMR(
  gender: Gender,
  weightKg: number,
  heightCm: number,
  age: number
): number {
  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;
  return gender === "male" ? base + 5 : base - 161;
}

export function calcTDEE(bmr: number, activityLevel: ActivityLevel): number {
  return bmr * ACTIVITY_FACTORS[activityLevel];
}

const KCAL_PER_KG_FAT = 7700;

export interface CalorieTargets {
  bmr: number;
  tdee: number;
  targetCalories: number;
  dailyAdjustment: number;
  proteinG: number;
  fatG: number;
  carbsG: number;
}

export function calcTargets(
  profile: Profile,
  currentWeightKg: number
): CalorieTargets {
  const bmr = calcBMR(
    profile.gender,
    currentWeightKg,
    profile.heightCm,
    profile.age
  );
  const tdee = calcTDEE(bmr, profile.activityLevel);

  const dailyAdjustment = (profile.weeklyRateKg * KCAL_PER_KG_FAT) / 7;
  let targetCalories = tdee + dailyAdjustment;

  // batas aman minimum kalori
  const floor = profile.gender === "male" ? 1500 : 1200;
  if (targetCalories < floor) targetCalories = floor;

  const proteinG = profile.proteinPerKg * currentWeightKg;
  const fatKcal = targetCalories * (profile.fatPercent / 100);
  const fatG = fatKcal / 9;
  const proteinKcal = proteinG * 4;
  const carbsKcal = Math.max(targetCalories - proteinKcal - fatKcal, 0);
  const carbsG = carbsKcal / 4;

  return {
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    targetCalories: Math.round(targetCalories),
    dailyAdjustment: Math.round(dailyAdjustment),
    proteinG: Math.round(proteinG),
    fatG: Math.round(fatG),
    carbsG: Math.round(carbsG),
  };
}

export function estimateCaloriesBurned(
  weightKg: number,
  met: number,
  durationMin: number
): number {
  // kalori = MET * 3.5 * berat(kg) / 200 * menit
  return Math.round((met * 3.5 * weightKg * durationMin) / 200);
}

export const ACTIVITY_MET: Record<string, number> = {
  lari_santai: 8,
  lari_sedang: 9.8,
  lari_cepat: 11.5,
  jalan_santai: 3.0,
  jalan_cepat: 4.3,
  kekuatan_ringan: 3.5,
  kekuatan_berat: 6.0,
  bersepeda: 7.5,
  renang: 7.0,
  yoga: 2.5,
  hiit: 8.5,
};

export function todayStr(): string {
  const d = new Date();
  return toDateStr(d);
}

export function toDateStr(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function formatDateLabel(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("id-ID", {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}

"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  ActivityEntry,
  AppData,
  FoodDbItem,
  MealEntry,
  Profile,
  WeightLog,
} from "./types";

const STORAGE_KEY = "body-goals-data-v1";

const DEFAULT_PROFILE: Profile = {
  name: "",
  gender: "male",
  age: 25,
  heightCm: 170,
  startWeightKg: 70,
  targetWeightKg: 65,
  activityLevel: "light",
  goalType: "cut",
  weeklyRateKg: -0.5,
  proteinPerKg: 1.8,
  fatPercent: 25,
  onboarded: false,
};

const DEFAULT_DATA: AppData = {
  profile: DEFAULT_PROFILE,
  weightLogs: [],
  meals: [],
  activities: [],
  customFoods: [],
};

function loadData(): AppData {
  if (typeof window === "undefined") return DEFAULT_DATA;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_DATA;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_DATA, ...parsed, profile: { ...DEFAULT_PROFILE, ...parsed.profile } };
  } catch {
    return DEFAULT_DATA;
  }
}

function saveData(data: AppData) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

interface StoreContextValue {
  data: AppData;
  ready: boolean;
  updateProfile: (patch: Partial<Profile>) => void;
  addWeightLog: (weightKg: number, date: string, note?: string) => void;
  deleteWeightLog: (id: string) => void;
  addMeal: (meal: Omit<MealEntry, "id">) => void;
  deleteMeal: (id: string) => void;
  addActivity: (activity: Omit<ActivityEntry, "id">) => void;
  deleteActivity: (id: string) => void;
  addCustomFood: (food: Omit<FoodDbItem, "id">) => FoodDbItem;
  resetAll: () => void;
  latestWeight: number;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<AppData>(DEFAULT_DATA);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setData(loadData());
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) saveData(data);
  }, [data, ready]);

  const updateProfile = useCallback((patch: Partial<Profile>) => {
    setData((prev) => ({ ...prev, profile: { ...prev.profile, ...patch } }));
  }, []);

  const addWeightLog = useCallback(
    (weightKg: number, date: string, note?: string) => {
      setData((prev) => {
        const withoutSameDay = prev.weightLogs.filter((w) => w.date !== date);
        const log: WeightLog = { id: uid(), date, weightKg, note };
        return {
          ...prev,
          weightLogs: [...withoutSameDay, log].sort((a, b) =>
            a.date.localeCompare(b.date)
          ),
        };
      });
    },
    []
  );

  const deleteWeightLog = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      weightLogs: prev.weightLogs.filter((w) => w.id !== id),
    }));
  }, []);

  const addMeal = useCallback((meal: Omit<MealEntry, "id">) => {
    setData((prev) => ({
      ...prev,
      meals: [...prev.meals, { ...meal, id: uid() }],
    }));
  }, []);

  const deleteMeal = useCallback((id: string) => {
    setData((prev) => ({ ...prev, meals: prev.meals.filter((m) => m.id !== id) }));
  }, []);

  const addActivity = useCallback((activity: Omit<ActivityEntry, "id">) => {
    setData((prev) => ({
      ...prev,
      activities: [...prev.activities, { ...activity, id: uid() }],
    }));
  }, []);

  const deleteActivity = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      activities: prev.activities.filter((a) => a.id !== id),
    }));
  }, []);

  const addCustomFood = useCallback((food: Omit<FoodDbItem, "id">) => {
    const item: FoodDbItem = { ...food, id: uid() };
    setData((prev) => ({ ...prev, customFoods: [...prev.customFoods, item] }));
    return item;
  }, []);

  const resetAll = useCallback(() => {
    setData(DEFAULT_DATA);
  }, []);

  const latestWeight = useMemo(() => {
    if (data.weightLogs.length === 0) return data.profile.startWeightKg;
    return data.weightLogs[data.weightLogs.length - 1].weightKg;
  }, [data.weightLogs, data.profile.startWeightKg]);

  const value: StoreContextValue = {
    data,
    ready,
    updateProfile,
    addWeightLog,
    deleteWeightLog,
    addMeal,
    deleteMeal,
    addActivity,
    deleteActivity,
    addCustomFood,
    resetAll,
    latestWeight,
  };

  return (
    <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
  );
}

export function useStore(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}

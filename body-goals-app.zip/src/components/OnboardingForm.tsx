"use client";

import { useState } from "react";
import { useStore } from "@/lib/store";
import { ACTIVITY_LABELS, GOAL_LABELS } from "@/lib/calc";
import { ActivityLevel, GoalType } from "@/lib/types";
import { Button, Field, inputCls } from "./ui";
import { todayStr } from "@/lib/calc";

export default function OnboardingForm() {
  const { updateProfile, addWeightLog } = useStore();
  const [step, setStep] = useState(0);

  const [name, setName] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [age, setAge] = useState(25);
  const [heightCm, setHeightCm] = useState(170);
  const [weightKg, setWeightKg] = useState(70);
  const [targetWeightKg, setTargetWeightKg] = useState(65);
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("light");
  const [goalType, setGoalType] = useState<GoalType>("cut");
  const [weeklyRateKg, setWeeklyRateKg] = useState(-0.5);

  const steps = ["Tentang kamu", "Ukuran tubuh", "Target & aktivitas"];

  function finish() {
    updateProfile({
      name,
      gender,
      age,
      heightCm,
      startWeightKg: weightKg,
      targetWeightKg,
      activityLevel,
      goalType,
      weeklyRateKg: goalType === "maintain" ? 0 : weeklyRateKg,
      onboarded: true,
    });
    addWeightLog(weightKg, todayStr(), "Berat awal");
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="text-[11px] uppercase tracking-[0.25em] text-ember font-semibold">
            Ledger
          </div>
          <h1 className="font-display text-3xl font-semibold mt-1">
            Buka buku catatanmu
          </h1>
          <p className="text-ink-soft text-sm mt-2">
            Tiga langkah singkat untuk menghitung kebutuhan kalori & target harianmu.
          </p>
        </div>

        <div className="flex items-center gap-2 mb-6">
          {steps.map((s, i) => (
            <div key={s} className="flex-1">
              <div
                className={`h-1 rounded-full ${
                  i <= step ? "bg-ink" : "bg-line"
                }`}
              />
              <div
                className={`text-[10px] mt-1.5 uppercase tracking-wide ${
                  i === step ? "text-ink font-semibold" : "text-ink-soft"
                }`}
              >
                {s}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-paper border border-line rounded-2xl p-6 animate-rise">
          {step === 0 && (
            <div className="space-y-4">
              <Field label="Nama panggilan">
                <input
                  className={inputCls}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="mis. Dinda"
                />
              </Field>
              <Field label="Jenis kelamin">
                <div className="grid grid-cols-2 gap-2">
                  {(["male", "female"] as const).map((g) => (
                    <button
                      key={g}
                      onClick={() => setGender(g)}
                      className={`rounded-xl border px-3 py-2.5 text-sm font-medium transition ${
                        gender === g
                          ? "bg-ink text-bone border-ink"
                          : "border-line hover:bg-line/30"
                      }`}
                    >
                      {g === "male" ? "Laki-laki" : "Perempuan"}
                    </button>
                  ))}
                </div>
              </Field>
              <Field label="Usia">
                <input
                  type="number"
                  className={inputCls}
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                />
              </Field>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4">
              <Field label="Tinggi badan (cm)">
                <input
                  type="number"
                  className={inputCls}
                  value={heightCm}
                  onChange={(e) => setHeightCm(Number(e.target.value))}
                />
              </Field>
              <Field label="Berat badan saat ini (kg)">
                <input
                  type="number"
                  step="0.1"
                  className={inputCls}
                  value={weightKg}
                  onChange={(e) => setWeightKg(Number(e.target.value))}
                />
              </Field>
              <Field label="Target berat badan (kg)">
                <input
                  type="number"
                  step="0.1"
                  className={inputCls}
                  value={targetWeightKg}
                  onChange={(e) => setTargetWeightKg(Number(e.target.value))}
                />
              </Field>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <Field label="Level aktivitas harian">
                <select
                  className={inputCls}
                  value={activityLevel}
                  onChange={(e) =>
                    setActivityLevel(e.target.value as ActivityLevel)
                  }
                >
                  {Object.entries(ACTIVITY_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Tujuan">
                <select
                  className={inputCls}
                  value={goalType}
                  onChange={(e) => {
                    const gt = e.target.value as GoalType;
                    setGoalType(gt);
                    if (gt === "cut") setWeeklyRateKg(-0.5);
                    if (gt === "bulk") setWeeklyRateKg(0.25);
                    if (gt === "maintain") setWeeklyRateKg(0);
                  }}
                >
                  {Object.entries(GOAL_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
              </Field>
              {goalType !== "maintain" && (
                <Field
                  label={`Laju ${
                    goalType === "cut" ? "penurunan" : "kenaikan"
                  } per minggu (kg)`}
                >
                  <input
                    type="number"
                    step="0.1"
                    min={0.1}
                    max={1}
                    className={inputCls}
                    value={Math.abs(weeklyRateKg)}
                    onChange={(e) =>
                      setWeeklyRateKg(
                        (goalType === "cut" ? -1 : 1) *
                          Math.abs(Number(e.target.value))
                      )
                    }
                  />
                  <span className="text-[11px] text-ink-soft mt-1 block">
                    Disarankan 0.25–0.75 kg/minggu agar aman & berkelanjutan.
                  </span>
                </Field>
              )}
            </div>
          )}

          <div className="flex justify-between mt-6">
            <Button
              variant="ghost"
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0}
            >
              Kembali
            </Button>
            {step < 2 ? (
              <Button onClick={() => setStep((s) => s + 1)}>Lanjut</Button>
            ) : (
              <Button onClick={finish}>Mulai catat</Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

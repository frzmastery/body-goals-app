"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { calcTargets, formatDateLabel, todayStr, toDateStr } from "@/lib/calc";
import { Card, MacroBar, SectionLabel } from "./ui";
import TallyRing from "./TallyRing";

function addDays(dateStr: string, delta: number): string {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + delta);
  return toDateStr(d);
}

export default function DashboardTab() {
  const { data, latestWeight } = useStore();
  const [date, setDate] = useState(todayStr());

  const targets = useMemo(
    () => calcTargets(data.profile, latestWeight),
    [data.profile, latestWeight]
  );

  const dayMeals = data.meals.filter((m) => m.date === date);
  const dayActivities = data.activities.filter((a) => a.date === date);

  const consumed = dayMeals.reduce((s, m) => s + m.calories, 0);
  const burned = dayActivities.reduce((s, a) => s + a.caloriesBurned, 0);
  const netConsumed = consumed - burned;

  const macros = dayMeals.reduce(
    (acc, m) => ({
      protein: acc.protein + m.protein,
      carbs: acc.carbs + m.carbs,
      fat: acc.fat + m.fat,
    }),
    { protein: 0, carbs: 0, fat: 0 }
  );

  const weightDiff = latestWeight - data.profile.targetWeightKg;
  const isToday = date === todayStr();

  const mealsByType: Record<string, typeof dayMeals> = {
    sarapan: [],
    makan_siang: [],
    makan_malam: [],
    camilan: [],
  };
  dayMeals.forEach((m) => mealsByType[m.mealType]?.push(m));
  const mealLabels: Record<string, string> = {
    sarapan: "Sarapan",
    makan_siang: "Makan siang",
    makan_malam: "Makan malam",
    camilan: "Camilan",
  };

  return (
    <div className="space-y-6 pb-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-ember font-semibold">
            {isToday ? "Hari ini" : "Riwayat"}
          </div>
          <h1 className="font-display text-2xl font-semibold">
            {data.profile.name ? `Halo, ${data.profile.name}` : "Ringkasan harian"}
          </h1>
        </div>
        <div className="flex items-center gap-1 bg-paper border border-line rounded-full px-1 py-1">
          <button
            onClick={() => setDate((d) => addDays(d, -1))}
            className="w-8 h-8 rounded-full hover:bg-line/40 flex items-center justify-center text-lg"
          >
            ‹
          </button>
          <span className="text-xs font-medium px-1 min-w-[92px] text-center">
            {formatDateLabel(date)}
          </span>
          <button
            onClick={() => setDate((d) => addDays(d, 1))}
            disabled={isToday}
            className="w-8 h-8 rounded-full hover:bg-line/40 flex items-center justify-center text-lg disabled:opacity-30"
          >
            ›
          </button>
        </div>
      </div>

      <Card className="flex flex-col items-center py-8">
        <TallyRing consumed={netConsumed} target={targets.targetCalories} />
        <div className="grid grid-cols-3 gap-6 mt-6 w-full text-center">
          <div>
            <div className="font-mono-num text-lg font-semibold">
              {Math.round(consumed).toLocaleString("id-ID")}
            </div>
            <div className="text-[11px] text-ink-soft uppercase tracking-wide">
              Asupan
            </div>
          </div>
          <div>
            <div className="font-mono-num text-lg font-semibold text-ember">
              -{Math.round(burned).toLocaleString("id-ID")}
            </div>
            <div className="text-[11px] text-ink-soft uppercase tracking-wide">
              Terbakar
            </div>
          </div>
          <div>
            <div className="font-mono-num text-lg font-semibold">
              {Math.round(targets.targetCalories).toLocaleString("id-ID")}
            </div>
            <div className="text-[11px] text-ink-soft uppercase tracking-wide">
              Target
            </div>
          </div>
        </div>
      </Card>

      <Card>
        <SectionLabel eyebrow="Gizi" title="Makronutrien hari ini" />
        <div className="space-y-4">
          <MacroBar label="Protein" value={macros.protein} target={targets.proteinG} color="var(--ember)" />
          <MacroBar label="Karbohidrat" value={macros.carbs} target={targets.carbsG} color="var(--sky)" />
          <MacroBar label="Lemak" value={macros.fat} target={targets.fatG} color="var(--lime-ink)" />
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <div className="text-[11px] text-ink-soft uppercase tracking-wide">Berat sekarang</div>
          <div className="font-mono-num text-2xl font-semibold mt-1">
            {latestWeight.toFixed(1)} <span className="text-sm font-normal">kg</span>
          </div>
          <div className="text-xs text-ink-soft mt-1">
            {weightDiff > 0
              ? `${weightDiff.toFixed(1)} kg menuju target`
              : weightDiff < 0
              ? `${Math.abs(weightDiff).toFixed(1)} kg lewat target`
              : "Target tercapai 🎉"}
          </div>
        </Card>
        <Card>
          <div className="text-[11px] text-ink-soft uppercase tracking-wide">TDEE</div>
          <div className="font-mono-num text-2xl font-semibold mt-1">
            {targets.tdee.toLocaleString("id-ID")}
          </div>
          <div className="text-xs text-ink-soft mt-1">
            {targets.dailyAdjustment === 0
              ? "Mode menjaga berat"
              : `${targets.dailyAdjustment > 0 ? "Surplus" : "Defisit"} ${Math.abs(
                  targets.dailyAdjustment
                )} kkal/hari`}
          </div>
        </Card>
      </div>

      <Card>
        <SectionLabel eyebrow="Catatan" title="Makan hari ini" />
        {dayMeals.length === 0 ? (
          <p className="text-sm text-ink-soft">Belum ada makanan dicatat. Buka tab Makanan untuk mulai mencatat.</p>
        ) : (
          <div className="space-y-3">
            {Object.keys(mealsByType).map((mt) =>
              mealsByType[mt].length ? (
                <div key={mt}>
                  <div className="text-xs font-semibold text-ink-soft mb-1">{mealLabels[mt]}</div>
                  {mealsByType[mt].map((m) => (
                    <div key={m.id} className="flex justify-between text-sm py-1 border-b border-line/60 last:border-0">
                      <span>{m.name}{m.qty !== 1 ? ` ×${m.qty}` : ""}</span>
                      <span className="font-mono-num text-ink-soft">{Math.round(m.calories)} kkal</span>
                    </div>
                  ))}
                </div>
              ) : null
            )}
          </div>
        )}
      </Card>

      {dayActivities.length > 0 && (
        <Card>
          <SectionLabel eyebrow="Catatan" title="Aktivitas hari ini" />
          <div className="space-y-1">
            {dayActivities.map((a) => (
              <div key={a.id} className="flex justify-between text-sm py-1 border-b border-line/60 last:border-0">
                <span>{a.label} · {a.durationMin} menit{a.distanceKm ? ` · ${a.distanceKm} km` : ""}</span>
                <span className="font-mono-num text-ember">-{a.caloriesBurned} kkal</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

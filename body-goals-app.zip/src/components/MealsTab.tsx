"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { searchFoodDb } from "@/lib/foodDb";
import { todayStr, formatDateLabel } from "@/lib/calc";
import { FoodDbItem, MealType } from "@/lib/types";
import { Button, Card, Field, SectionLabel, inputCls } from "./ui";

const MEAL_TYPES: { key: MealType; label: string }[] = [
  { key: "sarapan", label: "Sarapan" },
  { key: "makan_siang", label: "Makan siang" },
  { key: "makan_malam", label: "Makan malam" },
  { key: "camilan", label: "Camilan" },
];

export default function MealsTab() {
  const { data, addMeal, deleteMeal, addCustomFood } = useStore();
  const [date] = useState(todayStr());
  const [mealType, setMealType] = useState<MealType>("sarapan");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<FoodDbItem | null>(null);
  const [qty, setQty] = useState(1);
  const [showCustom, setShowCustom] = useState(false);

  const [customName, setCustomName] = useState("");
  const [customCal, setCustomCal] = useState(0);
  const [customProtein, setCustomProtein] = useState(0);
  const [customCarbs, setCustomCarbs] = useState(0);
  const [customFat, setCustomFat] = useState(0);

  const allFoods = useMemo(
    () => [...data.customFoods, ...searchFoodDb(query)],
    [data.customFoods, query]
  );
  const results = query
    ? allFoods.filter((f) => f.name.toLowerCase().includes(query.toLowerCase()))
    : searchFoodDb("");

  const todayMeals = data.meals.filter((m) => m.date === date);
  const todayTotal = todayMeals.reduce((s, m) => s + m.calories, 0);

  function handleAdd() {
    if (!selected) return;
    addMeal({
      date,
      mealType,
      name: selected.name,
      calories: selected.calories * qty,
      protein: selected.protein * qty,
      carbs: selected.carbs * qty,
      fat: selected.fat * qty,
      qty,
    });
    setSelected(null);
    setQty(1);
    setQuery("");
  }

  function handleAddCustom() {
    if (!customName || customCal <= 0) return;
    const item = addCustomFood({
      name: customName,
      unit: "1 porsi",
      calories: customCal,
      protein: customProtein,
      carbs: customCarbs,
      fat: customFat,
    });
    addMeal({
      date,
      mealType,
      name: item.name,
      calories: item.calories,
      protein: item.protein,
      carbs: item.carbs,
      fat: item.fat,
      qty: 1,
    });
    setCustomName("");
    setCustomCal(0);
    setCustomProtein(0);
    setCustomCarbs(0);
    setCustomFat(0);
    setShowCustom(false);
  }

  return (
    <div className="space-y-6 pb-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.2em] text-ember font-semibold">
          {formatDateLabel(date)}
        </div>
        <h1 className="font-display text-2xl font-semibold">Catat makanan</h1>
        <p className="text-sm text-ink-soft mt-1">
          Total hari ini:{" "}
          <span className="font-mono-num font-semibold text-ink">
            {Math.round(todayTotal)} kkal
          </span>
        </p>
      </div>

      <Card>
        <SectionLabel eyebrow="Tambah" title="Cari & catat makanan" />
        <div className="space-y-4">
          <Field label="Waktu makan">
            <div className="grid grid-cols-4 gap-2">
              {MEAL_TYPES.map((mt) => (
                <button
                  key={mt.key}
                  onClick={() => setMealType(mt.key)}
                  className={`rounded-xl border px-2 py-2 text-xs font-medium transition ${
                    mealType === mt.key
                      ? "bg-ink text-bone border-ink"
                      : "border-line hover:bg-line/30"
                  }`}
                >
                  {mt.label}
                </button>
              ))}
            </div>
          </Field>

          <Field label="Nama makanan">
            <input
              className={inputCls}
              placeholder="mis. nasi goreng, ayam bakar…"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setSelected(null);
              }}
            />
          </Field>

          {!selected && (
            <div className="border border-line rounded-xl divide-y divide-line max-h-56 overflow-y-auto">
              {results.length === 0 && (
                <div className="p-3 text-sm text-ink-soft">
                  Tidak ditemukan. Coba{" "}
                  <button
                    onClick={() => setShowCustom(true)}
                    className="underline font-medium text-ink"
                  >
                    tambah makanan custom
                  </button>
                  .
                </div>
              )}
              {results.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setSelected(f)}
                  className="w-full text-left px-3 py-2.5 hover:bg-line/30 flex justify-between items-center text-sm"
                >
                  <span>
                    {f.name}
                    <span className="text-ink-soft"> · {f.unit}</span>
                  </span>
                  <span className="font-mono-num text-ink-soft">{f.calories} kkal</span>
                </button>
              ))}
            </div>
          )}

          {selected && (
            <div className="rounded-xl border border-line p-3 bg-white space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-medium text-sm">{selected.name}</div>
                  <div className="text-xs text-ink-soft">{selected.unit}</div>
                </div>
                <button
                  onClick={() => setSelected(null)}
                  className="text-xs text-ink-soft hover:text-ink"
                >
                  Ganti
                </button>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-ink-soft">Porsi</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setQty((q) => Math.max(0.5, q - 0.5))}
                    className="w-7 h-7 rounded-full border border-line hover:bg-line/40"
                  >
                    −
                  </button>
                  <span className="font-mono-num w-10 text-center">{qty}</span>
                  <button
                    onClick={() => setQty((q) => q + 0.5)}
                    className="w-7 h-7 rounded-full border border-line hover:bg-line/40"
                  >
                    +
                  </button>
                </div>
                <span className="ml-auto font-mono-num text-sm font-semibold">
                  {Math.round(selected.calories * qty)} kkal
                </span>
              </div>
              <Button className="w-full" onClick={handleAdd}>
                Tambahkan
              </Button>
            </div>
          )}

          {!showCustom ? (
            <button
              onClick={() => setShowCustom(true)}
              className="text-xs text-ink-soft underline hover:text-ink"
            >
              + Tambah makanan custom (belum ada di daftar)
            </button>
          ) : (
            <div className="rounded-xl border border-line p-3 bg-white space-y-3">
              <Field label="Nama makanan">
                <input className={inputCls} value={customName} onChange={(e) => setCustomName(e.target.value)} />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Kalori (kkal)">
                  <input type="number" className={inputCls} value={customCal || ""} onChange={(e) => setCustomCal(Number(e.target.value))} />
                </Field>
                <Field label="Protein (g)">
                  <input type="number" className={inputCls} value={customProtein || ""} onChange={(e) => setCustomProtein(Number(e.target.value))} />
                </Field>
                <Field label="Karbo (g)">
                  <input type="number" className={inputCls} value={customCarbs || ""} onChange={(e) => setCustomCarbs(Number(e.target.value))} />
                </Field>
                <Field label="Lemak (g)">
                  <input type="number" className={inputCls} value={customFat || ""} onChange={(e) => setCustomFat(Number(e.target.value))} />
                </Field>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => setShowCustom(false)}>
                  Batal
                </Button>
                <Button onClick={handleAddCustom}>Simpan & catat</Button>
              </div>
            </div>
          )}
        </div>
      </Card>

      <Card>
        <SectionLabel eyebrow="Riwayat" title="Makanan hari ini" />
        {todayMeals.length === 0 ? (
          <p className="text-sm text-ink-soft">Belum ada catatan.</p>
        ) : (
          <div className="divide-y divide-line/60">
            {todayMeals.map((m) => (
              <div key={m.id} className="flex justify-between items-center py-2 text-sm">
                <div>
                  <div>{m.name}</div>
                  <div className="text-[11px] text-ink-soft">
                    P{Math.round(m.protein)} · K{Math.round(m.carbs)} · L{Math.round(m.fat)}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono-num">{Math.round(m.calories)} kkal</span>
                  <button
                    onClick={() => deleteMeal(m.id)}
                    className="text-ink-soft hover:text-ember text-xs"
                    aria-label="Hapus"
                  >
                    Hapus
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

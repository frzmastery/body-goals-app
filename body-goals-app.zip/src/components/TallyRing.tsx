"use client";

interface TallyRingProps {
  consumed: number;
  target: number;
  size?: number;
}

export default function TallyRing({ consumed, target, size = 220 }: TallyRingProps) {
  const ticks = 48;
  const pct = target > 0 ? Math.min(consumed / target, 1.3) : 0;
  const filledTicks = Math.round(Math.min(pct, 1) * ticks);
  const over = consumed > target;
  const remaining = target - consumed;

  const radius = size / 2;
  const tickLen = size * 0.07;
  const tickInnerR = radius - tickLen - 4;

  const marks = Array.from({ length: ticks }).map((_, i) => {
    const angle = (i / ticks) * 2 * Math.PI - Math.PI / 2;
    const x1 = radius + tickInnerR * Math.cos(angle);
    const y1 = radius + tickInnerR * Math.sin(angle);
    const x2 = radius + (tickInnerR + tickLen) * Math.cos(angle);
    const y2 = radius + (tickInnerR + tickLen) * Math.sin(angle);
    const filled = i < filledTicks;
    const isMajor = i % 12 === 0;
    return (
      <line
        key={i}
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        strokeWidth={isMajor ? 3 : 2}
        stroke={filled ? (over ? "var(--ember)" : "var(--ink)") : "var(--line)"}
        strokeLinecap="round"
      />
    );
  });

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {marks}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
        <span className="text-[11px] uppercase tracking-[0.15em] text-ink-soft">
          {over ? "Melebihi target" : "Sisa kalori"}
        </span>
        <span className="font-mono-num font-semibold text-3xl leading-tight mt-1">
          {Math.abs(Math.round(remaining)).toLocaleString("id-ID")}
        </span>
        <span className="text-[11px] text-ink-soft mt-1 font-mono-num">
          {Math.round(consumed).toLocaleString("id-ID")} / {Math.round(target).toLocaleString("id-ID")} kkal
        </span>
      </div>
    </div>
  );
}

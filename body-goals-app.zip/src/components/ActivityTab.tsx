"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { ACTIVITY_MET, estimateCaloriesBurned, formatDateLabel, todayStr } from "@/lib/calc";
import { ActivityType } from "@/lib/types";
import { Button, Card, Field, SectionLabel, inputCls } from "./ui";

const PRESETS: {
  type: ActivityType;
  key: string;
  label: string;
  hasDistance: boolean;
}[] = [
  { type: "lari", key: "lari_santai", label: "Lari santai", hasDistance: true },
  { type: "lari", key: "lari_sedang", label: "Lari sedang", hasDistance: true },
  { type: "lari", key: "lari_cepat", label: "Lari cepat", hasDistance: true },
  { type: "jalan_kaki", key: "jalan_santai", label: "Jalan santai", hasDistance: true },
  { type: "jalan_kaki", key: "jalan_cepat", label: "Jalan cepat", hasDistance: true },
  { type: "kekuatan", key: "kekuatan_ringan", label: "Angkat beban ringan", hasDistance: false },
  { type: "kekuatan", key: "kekuatan_berat", label: "Angkat beban berat", hasDistance: false },
  { type: "lainnya", key: "bersepeda", label: "Bersepeda", hasDistance: true },
  { type: "lainnya", key: "renang", label: "Berenang", hasDistance: false },
  { type: "lainnya", key: "yoga", label: "Yoga", hasDistance: false },
  { type: "lainnya", key: "hiit", label: "HIIT", hasDistance: false },
];

const CATEGORY_LABEL: Record<ActivityType, string> = {
  lari: "Lari",
  jalan_kaki: "Jalan kaki",
  kekuatan: "Latihan kekuatan",
  lainnya: "Lainnya",
};

export default function ActivityTab() {
  const { data, addActivity, deleteActivity, latestWeight } = useStore();
  const [date] = useState(todayStr());
  const [category, setCategory] = useState<ActivityType>("lari");
  const [presetKey, setPresetKey] = useState("lari_santai");
  const [durationMin, setDurationMin] = useState(30);
  const [distanceKm, setDistanceKm] = useState<number | "">("");

  const presetsForCategory = PRESETS.filter((p) => p.type === category);
  const preset = PRESETS.find((p) => p.key === presetKey) ?? presetsForCategory[0];

  const estimatedCalories = useMemo(() => {
    const met = ACTIVITY_MET[preset?.key ?? "lari_santai"] ?? 5;
    return estimateCaloriesBurned(latestWeight, met, durationMin);
  }, [preset, durationMin, latestWeight]);

  const todayActivities = data.activities.filter((a) => a.date === date);
  const todayBurned = todayActivities.reduce((s, a) => s + a.caloriesBurned, 0);

  function handleAdd() {
    if (!preset) return;
    addActivity({
      date,
      type: preset.type,
      label: preset.label,
      durationMin,
      distanceKm: preset.hasDistance && distanceKm !== "" ? Number(distanceKm) : undefined,
      caloriesBurned: estimatedCalories,
    });
    setDurationMin(30);
    setDistanceKm("");
  }

  return (
    <div className="space-y-6 pb-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.2em] text-ember font-semibold">
          {formatDateLabel(date)}
        </div>
        <h1 className="font-display text-2xl font-semibold">Catat aktivitas</h1>
        <p className="text-sm text-ink-soft mt-1">
          Terbakar hari ini:{" "}
          <span className="font-mono-num font-semibold text-ember">
            {Math.round(todayBurned)} kkal
          </span>
        </p>
      </div>

      <Card>
        <SectionLabel eyebrow="Tambah" title="Sesi olahraga baru" />
        <div className="space-y-4">
          <Field label="Kategori">
            <div className="grid grid-cols-4 gap-2">
              {(Object.keys(CATEGORY_LABEL) as ActivityType[]).map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setCategory(c);
                    const first = PRESETS.find((p) => p.type === c);
                    if (first) setPresetKey(first.key);
                  }}
                  className={`rounded-xl border px-2 py-2 text-xs font-medium transition ${
                    category === c
                      ? "bg-ink text-bone border-ink"
                      : "border-line hover:bg-line/30"
                  }`}
                >
                  {CATEGORY_LABEL[c]}
                </button>
              ))}
            </div>
          </Field>

          <Field label="Jenis">
            <select
              className={inputCls}
              value={presetKey}
              onChange={(e) => setPresetKey(e.target.value)}
            >
              {presetsForCategory.map((p) => (
                <option key={p.key} value={p.key}>
                  {p.label}
                </option>
              ))}
            </select>
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Durasi (menit)">
              <input
                type="number"
                className={inputCls}
                value={durationMin}
                onChange={(e) => setDurationMin(Number(e.target.value))}
              />
            </Field>
            {preset?.hasDistance && (
              <Field label="Jarak (km) — opsional">
                <input
                  type="number"
                  step="0.1"
                  className={inputCls}
                  value={distanceKm}
                  onChange={(e) =>
                    setDistanceKm(e.target.value === "" ? "" : Number(e.target.value))
                  }
                />
              </Field>
            )}
          </div>

          {distanceKm !== "" && Number(distanceKm) > 0 && (
            <p className="text-xs text-ink-soft">
              Pace: {(durationMin / Number(distanceKm)).toFixed(1)} menit/km
            </p>
          )}

          <div className="flex items-center justify-between rounded-xl bg-ember-soft px-4 py-3">
            <span className="text-sm text-ink-soft">Estimasi kalori terbakar</span>
            <span className="font-mono-num font-semibold text-ember text-lg">
              {estimatedCalories} kkal
            </span>
          </div>

          <Button className="w-full" onClick={handleAdd}>
            Tambahkan
          </Button>
        </div>
      </Card>

      <Card>
        <SectionLabel eyebrow="Riwayat" title="Aktivitas hari ini" />
        {todayActivities.length === 0 ? (
          <p className="text-sm text-ink-soft">Belum ada catatan aktivitas.</p>
        ) : (
          <div className="divide-y divide-line/60">
            {todayActivities.map((a) => (
              <div key={a.id} className="flex justify-between items-center py-2 text-sm">
                <div>
                  <div>{a.label}</div>
                  <div className="text-[11px] text-ink-soft">
                    {a.durationMin} menit{a.distanceKm ? ` · ${a.distanceKm} km` : ""}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono-num text-ember">-{a.caloriesBurned} kkal</span>
                  <button
                    onClick={() => deleteActivity(a.id)}
                    className="text-ink-soft hover:text-ember text-xs"
                  >
                    Hapus
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

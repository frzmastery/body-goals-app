"use client";

export type TabKey = "dashboard" | "makanan" | "aktivitas" | "berat" | "profil";

const TABS: { key: TabKey; label: string; icon: React.ReactNode }[] = [
  {
    key: "dashboard",
    label: "Ringkasan",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M4 13h6V4H4v9Zm0 7h6v-5H4v5Zm10 0h6V11h-6v9Zm0-16v5h6V4h-6Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    key: "makanan",
    label: "Makanan",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M6 3v8a3 3 0 0 0 3 3v7M6 3v6M9 3v6M6 9h3M18 3c-2 0-3 2-3 5s1 4 3 4v9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    key: "aktivitas",
    label: "Aktivitas",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M13 3 4 14h6l-1 7 9-11h-6l1-7Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    key: "berat",
    label: "Berat",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M3 17 9 6l3 5 3-8 6 14H3Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    key: "profil",
    label: "Profil",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="8" r="3.4" stroke="currentColor" strokeWidth="1.6" />
        <path d="M4.5 20c1.5-4 5-5.5 7.5-5.5S18 16 19.5 20" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
    ),
  },
];

export default function NavBar({
  active,
  onChange,
}: {
  active: TabKey;
  onChange: (t: TabKey) => void;
}) {
  return (
    <>
      {/* mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-paper border-t border-line z-40">
        <div className="flex justify-around">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => onChange(t.key)}
              className={`flex flex-col items-center gap-0.5 py-2.5 px-2 flex-1 text-[10px] font-medium ${
                active === t.key ? "text-ink" : "text-ink-soft"
              }`}
            >
              <span className={active === t.key ? "text-ember" : ""}>{t.icon}</span>
              {t.label}
            </button>
          ))}
        </div>
      </nav>

      {/* desktop side nav */}
      <nav className="hidden md:flex md:flex-col md:w-56 md:shrink-0 border-r border-line px-4 py-6 gap-1">
        <div className="mb-6 px-2">
          <div className="text-[11px] uppercase tracking-[0.25em] text-ember font-semibold">
            Ledger
          </div>
          <div className="font-display text-lg font-semibold">Body Goals</div>
        </div>
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => onChange(t.key)}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
              active === t.key
                ? "bg-ink text-bone"
                : "text-ink-soft hover:bg-line/40"
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </nav>
    </>
  );
}

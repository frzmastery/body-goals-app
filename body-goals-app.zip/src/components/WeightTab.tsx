"use client";

import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
  CartesianGrid,
} from "recharts";
import { useStore } from "@/lib/store";
import { formatDateLabel, todayStr } from "@/lib/calc";
import { Button, Card, Field, SectionLabel, inputCls } from "./ui";

export default function WeightTab() {
  const { data, addWeightLog, deleteWeightLog, latestWeight } = useStore();
  const [weightInput, setWeightInput] = useState(latestWeight);
  const [dateInput, setDateInput] = useState(todayStr());

  const chartData = useMemo(
    () =>
      data.weightLogs.map((w) => ({
        date: w.date,
        label: formatDateLabel(w.date),
        weight: w.weightKg,
      })),
    [data.weightLogs]
  );

  const target = data.profile.targetWeightKg;
  const start = data.profile.startWeightKg;
  const totalToGo = start - target;
  const progressed = start - latestWeight;
  const pct =
    totalToGo !== 0 ? Math.min(Math.max((progressed / totalToGo) * 100, 0), 100) : 100;

  function handleAdd() {
    if (!weightInput || weightInput <= 0) return;
    addWeightLog(weightInput, dateInput);
  }

  return (
    <div className="space-y-6 pb-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.2em] text-ember font-semibold">
          Progres
        </div>
        <h1 className="font-display text-2xl font-semibold">Berat badan</h1>
      </div>

      <Card>
        <div className="flex justify-between items-end mb-4">
          <div>
            <div className="text-[11px] text-ink-soft uppercase tracking-wide">Sekarang</div>
            <div className="font-mono-num text-3xl font-semibold">{latestWeight.toFixed(1)} kg</div>
          </div>
          <div className="text-right">
            <div className="text-[11px] text-ink-soft uppercase tracking-wide">Target</div>
            <div className="font-mono-num text-lg">{target.toFixed(1)} kg</div>
          </div>
        </div>
        <div className="h-2 rounded-full bg-line/60 overflow-hidden mb-1">
          <div
            className="h-full rounded-full bg-lime transition-all"
            style={{ width: `${pct}%` }}
          />
        </div>
        <div className="text-xs text-ink-soft">{pct.toFixed(0)}% menuju target</div>

        {chartData.length >= 2 && (
          <div className="h-56 mt-6">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid stroke="var(--line)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: "var(--ink-soft)" }}
                  axisLine={{ stroke: "var(--line)" }}
                  tickLine={false}
                  minTickGap={20}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "var(--ink-soft)" }}
                  axisLine={false}
                  tickLine={false}
                  domain={["dataMin - 2", "dataMax + 2"]}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--paper)",
                    border: "1px solid var(--line)",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  formatter={(v) => [`${v} kg`, "Berat"]}
                />
                <ReferenceLine y={target} stroke="var(--ember)" strokeDasharray="4 4" />
                <Line
                  type="monotone"
                  dataKey="weight"
                  stroke="var(--ink)"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: "var(--ink)" }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      <Card>
        <SectionLabel eyebrow="Tambah" title="Catat berat badan" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Tanggal">
            <input
              type="date"
              className={inputCls}
              value={dateInput}
              max={todayStr()}
              onChange={(e) => setDateInput(e.target.value)}
            />
          </Field>
          <Field label="Berat (kg)">
            <input
              type="number"
              step="0.1"
              className={inputCls}
              value={weightInput}
              onChange={(e) => setWeightInput(Number(e.target.value))}
            />
          </Field>
        </div>
        <Button className="w-full mt-4" onClick={handleAdd}>
          Simpan
        </Button>
      </Card>

      <Card>
        <SectionLabel eyebrow="Riwayat" title="Semua catatan" />
        {data.weightLogs.length === 0 ? (
          <p className="text-sm text-ink-soft">Belum ada catatan.</p>
        ) : (
          <div className="divide-y divide-line/60">
            {[...data.weightLogs].reverse().map((w) => (
              <div key={w.id} className="flex justify-between items-center py-2 text-sm">
                <span className="text-ink-soft">{formatDateLabel(w.date)}</span>
                <div className="flex items-center gap-3">
                  <span className="font-mono-num font-medium">{w.weightKg.toFixed(1)} kg</span>
                  <button
                    onClick={() => deleteWeightLog(w.id)}
                    className="text-ink-soft hover:text-ember text-xs"
                  >
                    Hapus
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

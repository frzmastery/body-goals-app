"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { ACTIVITY_LABELS, GOAL_LABELS, calcTargets } from "@/lib/calc";
import { ActivityLevel, GoalType } from "@/lib/types";
import { Button, Card, Field, SectionLabel, inputCls } from "./ui";

export default function ProfileTab() {
  const { data, updateProfile, resetAll, latestWeight } = useStore();
  const p = data.profile;
  const [confirmReset, setConfirmReset] = useState(false);

  const targets = useMemo(() => calcTargets(p, latestWeight), [p, latestWeight]);

  return (
    <div className="space-y-6 pb-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.2em] text-ember font-semibold">
          Pengaturan
        </div>
        <h1 className="font-display text-2xl font-semibold">Profil</h1>
      </div>

      <Card>
        <SectionLabel eyebrow="Kalkulasi" title="Kebutuhan kalori" />
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-ink-soft text-xs">BMR</div>
            <div className="font-mono-num font-semibold">{targets.bmr} kkal</div>
          </div>
          <div>
            <div className="text-ink-soft text-xs">TDEE</div>
            <div className="font-mono-num font-semibold">{targets.tdee} kkal</div>
          </div>
          <div>
            <div className="text-ink-soft text-xs">Target kalori</div>
            <div className="font-mono-num font-semibold">{targets.targetCalories} kkal</div>
          </div>
          <div>
            <div className="text-ink-soft text-xs">Protein / Karbo / Lemak</div>
            <div className="font-mono-num font-semibold">
              {targets.proteinG}/{targets.carbsG}/{targets.fatG} g
            </div>
          </div>
        </div>
      </Card>

      <Card>
        <SectionLabel eyebrow="Data diri" title="Informasi dasar" />
        <div className="space-y-4">
          <Field label="Nama panggilan">
            <input
              className={inputCls}
              value={p.name}
              onChange={(e) => updateProfile({ name: e.target.value })}
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Jenis kelamin">
              <select
                className={inputCls}
                value={p.gender}
                onChange={(e) => updateProfile({ gender: e.target.value as "male" | "female" })}
              >
                <option value="male">Laki-laki</option>
                <option value="female">Perempuan</option>
              </select>
            </Field>
            <Field label="Usia">
              <input
                type="number"
                className={inputCls}
                value={p.age}
                onChange={(e) => updateProfile({ age: Number(e.target.value) })}
              />
            </Field>
            <Field label="Tinggi (cm)">
              <input
                type="number"
                className={inputCls}
                value={p.heightCm}
                onChange={(e) => updateProfile({ heightCm: Number(e.target.value) })}
              />
            </Field>
            <Field label="Target berat (kg)">
              <input
                type="number"
                step="0.1"
                className={inputCls}
                value={p.targetWeightKg}
                onChange={(e) => updateProfile({ targetWeightKg: Number(e.target.value) })}
              />
            </Field>
          </div>
        </div>
      </Card>

      <Card>
        <SectionLabel eyebrow="Target" title="Aktivitas & tujuan" />
        <div className="space-y-4">
          <Field label="Level aktivitas harian">
            <select
              className={inputCls}
              value={p.activityLevel}
              onChange={(e) => updateProfile({ activityLevel: e.target.value as ActivityLevel })}
            >
              {Object.entries(ACTIVITY_LABELS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Tujuan">
            <select
              className={inputCls}
              value={p.goalType}
              onChange={(e) => {
                const gt = e.target.value as GoalType;
                updateProfile({
                  goalType: gt,
                  weeklyRateKg: gt === "maintain" ? 0 : gt === "cut" ? -0.5 : 0.25,
                });
              }}
            >
              {Object.entries(GOAL_LABELS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
          {p.goalType !== "maintain" && (
            <Field label={`Laju ${p.goalType === "cut" ? "penurunan" : "kenaikan"} per minggu (kg)`}>
              <input
                type="number"
                step="0.1"
                min={0.1}
                max={1}
                className={inputCls}
                value={Math.abs(p.weeklyRateKg)}
                onChange={(e) =>
                  updateProfile({
                    weeklyRateKg:
                      (p.goalType === "cut" ? -1 : 1) * Math.abs(Number(e.target.value)),
                  })
                }
              />
            </Field>
          )}
          <Field label="Protein target (gram per kg berat badan)">
            <input
              type="number"
              step="0.1"
              className={inputCls}
              value={p.proteinPerKg}
              onChange={(e) => updateProfile({ proteinPerKg: Number(e.target.value) })}
            />
          </Field>
          <Field label="Proporsi lemak (% dari total kalori)">
            <input
              type="number"
              className={inputCls}
              value={p.fatPercent}
              onChange={(e) => updateProfile({ fatPercent: Number(e.target.value) })}
            />
          </Field>
        </div>
      </Card>

      <Card>
        <SectionLabel eyebrow="Data" title="Kelola data" />
        <p className="text-xs text-ink-soft mb-3">
          Semua data tersimpan hanya di perangkat ini (localStorage), tidak dikirim ke server mana pun.
        </p>
        {!confirmReset ? (
          <Button variant="danger" onClick={() => setConfirmReset(true)}>
            Hapus semua data
          </Button>
        ) : (
          <div className="flex gap-2">
            <span className="text-sm text-ink-soft self-center">Yakin? Tidak bisa dibatalkan.</span>
            <Button variant="ghost" onClick={() => setConfirmReset(false)}>
              Batal
            </Button>
            <Button variant="danger" onClick={resetAll}>
              Ya, hapus
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
}

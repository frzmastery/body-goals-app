"use client";

import { useState } from "react";
import { useStore } from "@/lib/store";
import OnboardingForm from "@/components/OnboardingForm";
import NavBar, { TabKey } from "@/components/NavBar";
import DashboardTab from "@/components/DashboardTab";
import MealsTab from "@/components/MealsTab";
import ActivityTab from "@/components/ActivityTab";
import WeightTab from "@/components/WeightTab";
import ProfileTab from "@/components/ProfileTab";

export default function Home() {
  const { data, ready } = useStore();
  const [tab, setTab] = useState<TabKey>("dashboard");

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center text-ink-soft text-sm">
        Memuat…
      </div>
    );
  }

  if (!data.profile.onboarded) {
    return <OnboardingForm />;
  }

  return (
    <div className="flex min-h-screen bg-bone">
      <NavBar active={tab} onChange={setTab} />
      <main className="flex-1 px-4 md:px-10 py-6 md:py-10 pb-24 md:pb-10 max-w-2xl mx-auto md:mx-0 w-full">
        {tab === "dashboard" && <DashboardTab />}
        {tab === "makanan" && <MealsTab />}
        {tab === "aktivitas" && <ActivityTab />}
        {tab === "berat" && <WeightTab />}
        {tab === "profil" && <ProfileTab />}
      </main>
    </div>
  );
}
